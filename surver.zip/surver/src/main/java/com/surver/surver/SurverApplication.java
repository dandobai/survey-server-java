package com.surver.surver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SurverApplication {

	public static void main(String[] args) {
		SpringApplication.run(SurverApplication.class, args);
	}

}
