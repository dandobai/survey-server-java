package com.surver.surver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SurverApplicationTests {

	@Test
	void contextLoads() {
	}

}
